LocalLM Lab toolkit
===================

  localai-cli                    the command you run (config-aware wrapper)
  localai-playground-run         the engine it spawns
  localai-playground-run-compat  the engine on macOS 26 (Apple on-device model only)
  runtime/                       libraries + resources the engine loads

Keep runtime/ next to the executables — the folder moves as a unit.
Usage: https://github.com/ancientcomputing/locallm
